<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--<link rel="stylesheet" href="node_modules/sweetalert2/dist/sweetalert2.css">-->
    <script src=<?php echo e(URL("js/sweetalert2.all.js")); ?>></script>
    <script type="text/javascript" src="../js/setup.js"></script> 
    <script src=<?php echo e(URL("js/jquery.js")); ?>></script>
    <link rel="stylesheet" href=<?php echo e(asset('css/index.css')); ?> />
    <link rel="stylesheet" href=<?php echo e(asset('css/sweetalert2.css')); ?> />
    <link rel="stylesheet" href=<?php echo e(asset('css/setup.css')); ?> />
    <title>Sign</title>
</head>
<script>
    function disableBack() { window.history.forward(); }
    setTimeout("disableBack()", 0);
    window.onunload = function () { null };
    var counter = 0,totalWarehouses=0;
    var warehouseId = "",warehouseName = "",accountId = "",accountName="",accountRole="",accountUserId="";
    function registerOnClick(){
        document.getElementById("loginContainer").style.display = "none";
        document.getElementById("registrationCon").style.display = "block";
        console.log("Register");
        //$('#name').val = ""; 
        document.getElementById('name').value = '';
        document.getElementById('id').value = '';
        document.getElementById('regPassword').value = '';
        document.getElementById('confirmRegPassword').value = '';
        document.getElementById('adminId').value = '';
    }

  function loginOnClick(){
    document.getElementById("loginContainer").style.display = "block";
    document.getElementById("registrationCon").style.display = "none";
  }

  function currentWarehouse(e){
   
    
    //alert(counter);
    for(var i=0;i<counter;i++){
        var id = "warehouseSelectItem"+i;
        document.getElementById(id).style.background = "white";
        var child = document.getElementById(id).childNodes;
        child[0].style.color = "black";
    }
    var id2 = e.id;
    var children = document.getElementById(id2).childNodes;
    children[0].style.color = "white";
    document.getElementById(id2).style.background = "#009933";

    //Get warehouse Id = 
    warehouseId = children[1].id;

    //Get warehouse Name = 
    warehouseName = children[0].innerHTML;
 
    
  }

  function showError(title,message){
    Swal.fire({
                        icon: 'error',
                        title: title,
                        text: message,
                        
    }); 
  }

  function showSuccess(title,message){
    Swal.fire({
            icon: 'success',
            title: title,
            text: message,
    }); 
  }

  function goHome(){
    if(warehouseId!=""){
        var accountsRequest  = $.ajax({
                                        url:"/accountant",
                                        method: "GET",
                                        data:{
                                            wid:warehouseId,
                                            wname:warehouseName,
                                            accountId:accountId,
                                            accountName:accountName,
                                            accountUserId:accountUserId,
                                            "_token": "<?php echo e(csrf_token()); ?>"
                                        }
        });
        accountsRequest.done(function (response, textStatus, jqXHR){
          // console.log("Response: "+response);
          if(response == "Success"){
            window.location.replace('/home');
          }
        });
        accountsRequest.fail(function (){
          showError("Failure","Please check Internet")
        });
    }
    else{
        showError("Error","Please select ware house to proceed");
    }  
  }

  function login(){
     

     $id = $("#userId").val();
     $password = $("#userPassword").val();

     if($id.length == 0){
       showError("Invalid Enrty","User Id required ");
     }
     else if($password.length<6){
       showError("Invalid Enrty","User Password should be at least 6 characters ");  
     }
     else{
        
       alert("Ready to rambo");
      
     }
  
   }

</script>    
<body>

    
    <div id="mainContainer">
        <div id="centerContainer">
          <div id="leftImage">
             <img id="leftImg" src=<?php echo e(asset('images/ware_house.jpg')); ?>>
          </div>
          <div id="rightCon">
             <div class=centerVertically id="loginContainer">
                 <div class=lCon>
                     <label class="title">Franko Ware House</label>
                     <label id="subTitle">Ware house management system</label>
                     <form action="<?php echo e(route('loginData')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div id="con1">
                            <input class="inputDesign authTxtInput" name="login_user_id" id="userId" type="text" placeholder="User ID">
                        </div>
                        <?php $__errorArgs = ['login_user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <script>
                                showError('Error',"<?php echo e($message); ?>");
                            </script>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="con2">
                            <input class="inputDesign authTxtInput" name="login_password" id="userPassword" type="password" placeholder="Password">
                        </div>
                        <?php $__errorArgs = ['login_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <script>
                                showError('Error',"<?php echo e($message); ?>");
                            </script>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="con2">
                            <button type="submit" class="buttonDesign authTxtInput" id="loginBtn">Log In</button>
                        </div>
                     </form>
                      <div class="con2">
                          <label id="register" onclick="registerOnClick()">Register</label>
                      </div>
                 </div>
             </div>
 
             <div class=centerVertically id=registrationCon>
                 <div class=lCon>
                     <label class="title">Franko Ware House</label>
                     <label id="subTitle">Ware house management system</label>
                     <form action="<?php echo e(route('saveData')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <?php if($errors->any()): ?>
                            <script>
                                showError("Error","<?php echo e($errors->first()); ?>");
                            </script>
                        
                        <?php endif; ?>

                        <?php if(Session::has('success')): ?>

                            <script>
                                showSuccess('Registration Success','Please contact administrator for account verification');
                            </script>

                        <?php endif; ?>

                        <div id="con1">
                            <input class="inputDesign authTxtInput" name="name" id="name" type="text" placeholder="Name">
                        </div>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <script>
                                    showError('Error',"<?php echo e($message); ?>");
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="con2">
                            <input class="inputDesign authTxtInput" id="id" name="user_id" type="text" placeholder="User ID">
                        </div>
                            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <script>
                                    showError('Error',"<?php echo e($message); ?>");
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="con2">
                            <input class="inputDesign authTxtInput" id="regPassword" name="password" type="password" placeholder="Password">
                        </div>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <script>
                                    showError('Error',"<?php echo e($message); ?>");
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="con2">
                            <input class="inputDesign authTxtInput" id="confirmRegPassword" name="confirm_password" type="password" placeholder="Confirm Password">
                        </div>
                            <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <script>
                                    showError('Error',"<?php echo e($message); ?>");
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="con2">
                            <input class="inputDesign authTxtInput" id="adminId" type="text" name="adminId" placeholder="Admin ID">
                        </div>
                            <?php $__errorArgs = ['adminId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <script>
                                showError('Error',"<?php echo e($message); ?>");
                            </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="con2">
                            <button type="submit" class="buttonDesign authTxtInput"  id="registerBtn">Register</button>
                        </div>
                    </form>
                     <div class="con2">
                         <label id="login" onclick="loginOnClick()">Login</label>
                     </div>
                 </div>
             </div>
          </div>
        </div>
     </div>
     <div id="warehouseSelectModalCon">
        <div id="centerWarehouseModal">
           <div class="welcomeCon">
              <label id="headingTxt">Welcome 
                  <?php if(isset($accountant)): ?>
                      <?php echo e($accountant->name); ?>

                      <script>
                          accountId = "<?php echo e($accountant->id); ?>";
                          accountName = "<?php echo e($accountant->name); ?>";
                          accountUserId = "<?php echo e($accountant->user_id); ?>";
                      </script>
                  <?php endif; ?>
              </label>
           </div>
           <div class="welcomeCon2">
                <label id="subHeading">
                    Accountant Profile
                </label>
           </div>
           <div class="welcomeCon2">
                <label id="subHeading">
                    Select Warehouse To Proceed.
                </label>
           </div>
           <div class="verticalSpace"></div>
           <?php if(isset($accountant)): ?>
                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <script>
                        var warehouseItem = document.createElement('div');
                        warehouseItem.classList.add('warehouseSelectItem');
                        warehouseItem.id = "warehouseSelectItem"+counter;
                        warehouseItem.setAttribute('onclick', 'currentWarehouse(this)');

                        //label
                        var warehouseLable = document.createElement('label');
                        warehouseLable.classList.add('warehouseLable');
                        warehouseLable.innerHTML = "<?php echo e($data->wname); ?>";

                        //Img
                        var warehouseTick = document.createElement('img');
                        warehouseTick.classList.add('warehouseTick');
                        warehouseTick.setAttribute("src","icons/correct.png");
                        warehouseTick.id = "<?php echo e($data->id); ?>";


                        warehouseItem.appendChild(warehouseLable);
                        warehouseItem.appendChild(warehouseTick);

                        var centerWarehouse = document.getElementById("centerWarehouseModal");
                        centerWarehouse.appendChild(warehouseItem);
                        counter = counter + 1;

                    </script>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <div id="containerCon">
                   <button id="selectWarehouse" onclick="goHome()">Proceed</button>
                </div>
           <?php endif; ?>
        </div>
     </div>
     <script>

        var accountant = "<?php echo e($accountant ?? ''); ?>";
        if(accountant != ''){
            document.getElementById('warehouseSelectModalCon').style.display = "block";
        }
    </script>
</body>
</html><?php /**PATH C:\laragon\www\frankowarehouse\resources\views/login.blade.php ENDPATH**/ ?>