<footer>
    <div class="container-footer">
        <img 
            src="https://cdn.pixabay.com/photo/2017/02/18/19/20/logo-2078018_960_720.png" 
            alt="Logo personal portfolio"
            title="Logo personal portfolio"
            />
        <p>
            This website is created by Code With Dary
        </p>
    </div>
        
</footer>